# Family Monitor Android

Starter family safety / anti-scam monitoring application.

## Compatibility
- Minimum Android: 10 (API 29)
- Target Android: 15 (API 35)

## Current features
- Explicit location permission request
- Explicit SMS permission request
- Explicit call-log permission request
- App-usage settings shortcut
- Location settings shortcut
- Visible foreground monitoring service
- Anti-scam oriented foundation

## Important
This project intentionally does NOT attempt to:
- read WhatsApp or Telegram private databases
- capture banking passwords, PINs, OTPs or card credentials
- secretly record calls
- secretly activate microphone/camera
- hide the monitoring service

Additional Android restrictions and Google Play policies may apply to SMS/call-log access. For a private family deployment, permissions must still be granted on the child's device.

Open the project in Android Studio and build the debug APK with:
./gradlew assembleDebug
