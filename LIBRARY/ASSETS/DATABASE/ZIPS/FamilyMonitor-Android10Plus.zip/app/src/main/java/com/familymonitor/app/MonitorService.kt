package com.familymonitor.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat

class MonitorService : Service() {
    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(
            "monitoring", "Family Monitor", NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)

        val notification: Notification = NotificationCompat.Builder(this, "monitoring")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("Family Monitor is active")
            .setContentText("Family safety monitoring is running.")
            .setOngoing(true)
            .build()

        startForeground(1001, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int =
        START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null
}
