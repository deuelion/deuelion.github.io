# MLAK Charity Organisation Website

A modern static HTML/CSS/JS NGO/charity website.

## Pages
- Home
- About
- Programs
- Impact
- Volunteer
- Donate
- Contact

## Before going live
1. Replace placeholder phone/email/address.
2. Replace illustrative impact figures with verified figures.
3. Connect forms to a secure backend or trusted form service.
4. Connect the donation page to your approved payment gateway/server.
5. Add your legal registration details and applicable policies.
6. Add real, consented photos and stories.
7. Publish Privacy, Safeguarding/Child Protection, Complaints, Donation/Refund and Terms policies.
8. Configure HTTPS, backups and spam protection.
